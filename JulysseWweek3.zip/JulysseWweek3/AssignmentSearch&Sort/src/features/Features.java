package features;

import java.util.Arrays;
import java.util.Scanner;

public abstract class Features {
	public static int read() {
		Scanner source=new Scanner(System.in);
		return source.nextInt();
	}
	
	public static void insert (int[]table) {
		for(int i=0; i<table.length; i++) {
			System.out.println("                				Enter the element whose position is : " + (i + 1 )) ;
			table[i]=Features.read();
		}
		
	}
	
	public static void display(String Affichage) {
		System.out.println(Affichage);
	}
	
	public static void displayTable(int[] tab) {
		display(Arrays.toString(tab));
	}
	
	public static int postiveInteger() {
		display("Enter a positive value for the table size ");
		int n = read();
		while(n < 1) { 
			display("Error, retry");
			display("Entrer une valeur positive");
			n = read();
	}
	return n;
	}
	
}
