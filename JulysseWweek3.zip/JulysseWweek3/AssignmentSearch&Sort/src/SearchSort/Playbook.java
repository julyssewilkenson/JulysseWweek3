package SearchSort;

import java.util.Arrays;

import features.Features;

public class Playbook {
	
public static void main (String[] args) {
	int l=Features.postiveInteger();
	int[] table= new int[l];
	
	Features.display("        		     You are going to fill the array, Press enter each time you enter a number");
	Features.insert(table);
	Features.displayTable(table);
	sort(table);
	Features.displayTable(table);
	Features.display("Enters to check if a value is in the table");
	int value = Features.read();
	if(search(table,value)) {
		Features.display("Not founded");
	}
	else {
		Features.display("Founded");
	}
	
	
	 
}

public static void sort(int[] table) {
	Features.display("                     Choose the Method you want to sort your array ");
	Features.display("                  	 	  1.  Bubble Sort");
	Features.display("                	 	   	  2.  Selection Sort");
	Features.display("                		      3.  Shell sort ");
	Features.display("                		      4.  Insertion Sort ");
	
	int t = Features.read();
	switch(t) {
	case 1 :{
		Tools.tri_bu(table);
	}break;
	
	case 2 :{
			Tools.tri_select(table);
		}break;
		
	case 3 :{
		Tools.shell_sort(table);
	}break;
	
	case 4 :{
		Tools.insertion(table);
	}break;
	
	default:{
		sort(table);
	}
	
	}
}

public static boolean search(int[] table,int y) {
	Features.display("                     Choose the method you want to search in your array ");
	Features.display("                  1.  dichotomic method");
	Features.display("                  2.  exponential method");
	Features.display("                  3.  linear method ");
	Features.display("                  4.  Method Jump ");
	
	int t = Features.read();
	switch(t) {
	case 1 :{
		return Tools.dicho(table,y);
	}
	
	case 2 :{
		return Tools.ExpoSearch(table,y);
		}
		
	case 3 :{
		return Tools.line(table, y);
	}
	
	case 4 :{
		Tools.jumpSearch(table, y);
	}
	
	default:{
		return search(table,y);
	}
	
	}
}

}
