package SearchSort;

public class Tools {
	// methode de comparaison
	public static boolean comparaison(int a, int b, String ordre)
	{
		if (ordre.equals("c") || ordre.equals("C"))
			return a<b;
		else
			return a>b;
	}
		
	
	
	
	
	
	//tri a bulle
	public static void tri_bu(int []table) {
		for(int i=0; i<table.length; i++) {
			for(int j=0; j<table.length-1; j++) {
				if (table[j+1] < table[j]) {
					int temp = table [j];
					table[j]= table[j+1];
					table[j+1]= temp;
				}
			}
			
		}
			
	}

	//tri selection
	public static void tri_select(int []table) {
		int i;
		int j;
		int low;
		int temp;
		for(i=0; i<table.length-1; i++) {
			low =i;
			for (j=i+1; j<table.length; j++) {
				if(table[j] <= table[low]) {
					low = j;
				}
			}
			temp = table[i];
			table[i]=table[low];
			table[low]=temp;
		}
		
	}
	
	//shell Sort
	
	public static void shell_sort(int table[])
	{
		int i = 0, j = 0, k = 0, mid = 0;
		for (k = table.length /2; k>0; k/=2 )
		{
			for (j = k; j <table.length; j++)
			{
				for( i = j-k; i>=0; i-=k )
				{
					if (table[i+k] >= table[i])
					{
						break;
					}
					else 
					{
						mid = table[i];
						table[i] = table[i+ k];
						table[i +k] = mid;
					}
				}
			}
		}
	}
	
	
	public static void insertion(int [] x)
	{
		int temp, i, j;
		for(i= 1; i<x.length; i++)
		{
			temp = x[i];
			j = i-1;
			while (j>=0 && temp <x[j])
			{
				x[j+1] = x[j];
				j = j - 1;
			}
			x[j + 1] = temp;
		}
	}
	
	
	
	
	//*****************************************
	
//	Searching Methods
	
	//dichotomique
	
	public static boolean dicho(int []table, int y) {
		shell_sort(table);
		int start = 0;
		int end = table.length;
		int center=0; 
		boolean out = false;
		while (out!= true && start <= end) {
			center = (int) (start + end )/2;
			if ( table[center] == y ) {
				out = true;
				
			} 
			else if (y > table[center]) {
				start = center +1;
			}
			else {
				end = center - 1;
			}
		}
		return out;
		
	}
		
	
	
//exponentielle
	
	public static boolean ExpoSearch(int [] table, int x)
 { 
		tri_select(table);
		int n = table.length;
	 if (table[0]== x )
		 return true;
	 
	 int i = 1;
	 while (i < n && table[i] <= x) 
		 i = i*2;
	 return dicho(table, x); 
 }
	
	
	
	
	//lineaire Search
	public static boolean line(int []table, int p)
	{
		for (int i=0; i<table.length; i++) {
			if (table[i]==p)
			{
				return true;
			}
		}
		return false;
	}
	
	
	
//  jumpSearch
	
	
	public static boolean jumpSearch(int [] table, int target)
	{
		tri_bu(table);
		int size = table.length;
		int step = (int) Math.floor(Math.sqrt(size));
		int prev = 0;
		while (table [(Math.min(step, size)) - 1] < target)
		{
			prev = step;
			step *= 2;
			if (prev >= size)
				return false;
		}
		while (table[prev] < target ) {
			prev++;
			if (prev == Math.min(size, step))  
			{
				return false;
			}
		}
		if (table[prev] == target)
		{
			return true;
		}
		return false;
	}
	
	
	 
	
	
	
	
	
}
	